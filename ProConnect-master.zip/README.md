# ProConnect

ProConnect is a web-based application that matches its users with companies together based on user listed traits (e.g., experience, languages education, work style...). ProConnect allows users to customize their individual profile to better showcase personal projects and resumes. 

## Installation

To be added....

```bash

```

## Usage

```bash
- Run local MongoDB using the cmd: 'mongod'
- Start the server using the cmd: 'nodemon app.js'
- Open browser and go to 'localhost:3000'

```

## Tools

```python

```

## Team Members
```python
San Jose State University

- Jonah Morgan Gonzalez
- Braulio Mendoza
- Kevin Pham
- Andrew Wilson
```

## Credit
[BootSnipp - Bootstrap Profile Page Design](https://bootsnipp.com/snippets/K0ZmK)
